readme.txt for ShipPlotter.XLS

Unzip/Download shipplotter.xls into My Documents

Start COAA's ShipPlotter.exe

When some ships are displayed:-

Use Excel to open shipplotter.xls

Enable macros

If asked allow it to communication with 80.176.254.178

On the Menu bar of the spreadsheet click ShipPlotter > Help
for detailed instructions.

